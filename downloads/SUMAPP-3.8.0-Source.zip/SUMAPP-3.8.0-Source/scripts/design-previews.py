#!/usr/bin/env python3
"""Render labelled design previews from shared Core geometry; these are not WPF screenshots.
Run setup-cloud.sh first. Optional preview tool requires PyMuPDF, not the Windows app.
"""
from pathlib import Path
import base64
import html
import json
import fitz

root = Path(__file__).resolve().parents[1]
fixture = json.loads((root / 'artifacts/export-checks/SUMAPP-design.json').read_text())
T = fixture['Theme']
logo = base64.b64encode((root / 'src/EireTodo.Windows/Assets/SumappLogo.png').read_bytes()).decode()
shapes = json.loads((root / 'artifacts/export-checks/SUMAPP-shapes.json').read_text())
gallery = json.loads((root / 'artifacts/export-checks/SUMAPP-gallery.json').read_text())
out = root / 'previews'
out.mkdir(exist_ok=True)
W, H = 1600, 900

def text(x, y, value, colour=None, size=17, bold=False):
    return f'<text x="{x}" y="{y}" fill="{colour or T["Ink"]}" font-size="{size}" font-family="sans-serif" font-weight="{"bold" if bold else "normal"}">{html.escape(str(value))}</text>'

def pdf_text(d):
    mark=text(d['X'],d['Y'],d['Text'],d['Colour'],d['Size'],d['Bold'])
    if d.get('Centre'): mark=mark.replace('<text ', '<text text-anchor="middle" ',1)
    if d.get('Angle'): mark=f'<g transform="rotate({d["Angle"]} {d["X"]} {d["Y"]})">'+mark+'</g>'
    return mark

def rect(x, y, w, h, fill, stroke='', radius=4):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{fill}" stroke="{stroke or "none"}" stroke-width="1"/>'

def node_shape(d):
    if d['Shape']==2: return rect(d['X'],d['Y'],d['Width'],d['Height'],d['Fill'],d['Stroke'],10)
    c=d['Contour'];start=c['Start'];path='M'+str(start['X'])+' '+str(start['Y'])
    for segment in c['Segments']:
        end=segment['End'];a=segment.get('Control1');b=segment.get('Control2')
        path+=(' C'+str(a['X'])+' '+str(a['Y'])+' '+str(b['X'])+' '+str(b['Y'])+' '+str(end['X'])+' '+str(end['Y'])) if a else (' L'+str(end['X'])+' '+str(end['Y']))
    return f'<path d="{path} Z" fill="{d["Fill"]}" stroke="{d["Stroke"]}" stroke-width="{d["Thickness"]}"/>'

def frame(module, active_tab='Home'):
    s = [f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{W}" height="{H}">', rect(0,0,W,H,T['Surface']),rect(0,0,W,48,T['Black'],radius=0),rect(0,0,W,3,T['Yellow'],radius=0),rect(10,8,34,34,'#FFFFFF'), f'<image x="12" y="10" width="30" height="30" xlink:href="data:image/png;base64,{logo}"/>',text(54,33,'SUMAPP','#FFFFFF',20,True)]
    for x,label in [(W-120,'−'),(W-80,'□'),(W-40,'×')]:s.append(text(x+13,32,label,'#FFFFFF',17))
    for x,label in [(8,'File'),(76,'Home'),(144,'Insert'),(212,'Format'),(280,'View')]:
        s += [rect(x,48,68,30,T['DarkTeal'] if label==active_tab else T['Surface'],radius=2),text(x+10,69,label,'#FFFFFF' if label==active_tab else T['Ink'],14,True)]
    s += [rect(0,78,W,106,'#FFFFFF',radius=0)]
    # Existing demo coordinates are translated to the smaller ribbon/canvas.
    s += ['<g transform="translate(0 -69)">']
    return s

def action(s, x, y, label, primary=False, icon='plus'):
    width = len(label)*8+44
    colour = T['DarkTeal'] if primary else T['Ink']
    if icon=='plus': motif=f'M{x+12} {y-14} v16 M{x+4} {y-6} h16'
    elif icon=='trash': motif=f'M{x+4} {y-13} h16 M{x+7} {y-13} v16 h10 v-16 M{x+9} {y-17} h6'
    else: motif=f'M{x+4} {y-15} h16 v18 h-16 z M{x+8} {y-10} h8 M{x+8} {y-4} h8'
    s.append(f'<path d="{motif}" stroke="{colour}" fill="none" stroke-width="1.25"/>')
    s.append(text(x+28,y,label,colour,14))

def save(name, parts):
    parts += ['</g>',text(W-240,H-18,'07/10/2026 14:30:45',T['Ink'],15.6),text(16,H-20,'DESIGN PREVIEW · Shared Core styles and geometry · Native Windows screenshot not captured',T['Ink'],13),'</svg>']
    svg = ''.join(parts).encode()
    (out / (name+'.svg')).write_bytes(svg)
    document=fitz.open(stream=svg,filetype='svg'); pdf=fitz.open(stream=document.convert_to_pdf(),filetype='pdf')
    pdf[0].get_pixmap(matrix=fitz.Matrix(1,1)).save(out / (name+'.png'))
    (out / (name+'.html')).write_text('<!doctype html><title>SUMAPP design preview</title><body style="margin:0">'+svg.decode()+'</body>')

s=frame('TO-DO')
s += [rect(12,162,190,28,T['Surface'],T['DarkTeal']),text(22,182,'To-do     ⌄',T['Ink'],14),text(12,245,'APPLICATION',size=11)]
action(s,225,182,'Add task',True); action(s,225,216,'Edit / notes',icon='doc'); action(s,422,182,'Delete',icon='trash'); action(s,422,216,'Projects',icon='doc');action(s,660,182,'Colour presets…',icon='doc');action(s,660,216,'Row design…',icon='doc')
s += [text(225,245,'EDIT',size=11),text(422,245,'PROJECTS',size=11)]
s += [rect(12,267,W-24,107,'#FFFFFF'),text(25,288,'PROJECT VIEW',size=14,bold=True),rect(25,298,200,40,'#FFFFFF',T['DarkTeal']),text(37,324,'All projects',size=17),text(241,288,'SEARCH TASK',size=14,bold=True),rect(241,298,220,40,'#FFFFFF',T['DarkTeal']),rect(480,309,22,22,'#FFFFFF',T['DarkTeal']),text(512,326,'Hide completed',size=16)]
action(s,683,324,'Clear filters',icon='doc');s.append(text(27,363,'⌄  More filters · notes, category, status and dates',size=16))
cols=[('Status',155),('Project',160),('Task',300),('Start date',135),('Finish date',135),('Category',160),('Notes',220),('Created date / time',205)]
x=12
for label,width in cols: s += [rect(x,389,width,44,T['SoftTeal'],radius=0),text(x+12,417,label,T['DarkTeal'],16,True)];x+=width
rows=[('Steel fabrication BOQ','Procurement','14/10/2026',False,True),('Guide rail','Fabrication','15/10/2026',True,False),('Chain hooks','Fabrication','05/10/2026',False,False),('Chain supports','Fabrication','17/10/2026',False,False),('Pipe supports','Fabrication','18/10/2026',False,False)]
for i,(title,category,finish,done,priority) in enumerate(rows):
    y=433+i*65; colour='#B42318' if i==2 else T['Ink'];s.append(rect(12,y,1470,65,'#FFFFFF' if i!=3 else T['SoftTeal'],radius=0)); x=12
    s += [rect(x+10,y+21,22,22,T['DarkTeal'] if done else '#FFFFFF',T['DarkTeal']),text(x+12,y+39,'✓' if done else '','#FFFFFF',17),rect(x+43,y+20,98,26,T['SoftTeal']),text(x+49,y+38,'Completed' if done else 'To do',T['DarkTeal'],12)]
    x+=155;s.append(text(x+10,y+31,'SOU001',colour)); x+=160;s.append(text(x+10,y+27,title,colour));s.append(text(x+10,y+49,'SOU001 · '+category,T['Ink'],13))
    if priority:s += [rect(x+213,y+36,76,18,T['Yellow']),text(x+217,y+49,'PRIORITY',T['Black'],11,True)]
    x+=300;s.append(text(x+10,y+31,'03/10/2026' if i==2 else '07/10/2026',colour));x+=135;s.append(text(x+10,y+31,finish,colour));x+=135;s.append(text(x+10,y+31,category,colour));x+=160;s.append(text(x+10,y+31,'Review drawing and…',colour));x+=220;s.append(text(x+10,y+31,'07/10/2026 09:48',colour))
    s.append(f'<path d="M12 {y+65} H1482" stroke="{T["DarkTeal"]}" stroke-opacity="0.2"/>')
s += [rect(12,772,1470,5,T['SoftTeal']),rect(12,772,1000,5,T['DarkTeal']),text(14,824,'5 tasks · 1 completed · 1 overdue',size=16)]
action(s,340,824,'Show overdue log',icon='doc')
save('SUMAPP-to-do-design',s)

s=frame('MIND MAP / WBS')
s += [rect(12,162,190,28,T['Surface'],T['DarkTeal']),text(22,182,'Mind map / WBS   ⌄',size=14),text(12,245,'APPLICATION',size=11)]
s += [rect(222,162,210,28,T['Surface'],T['DarkTeal']),text(232,182,'Mechanical items  ⌄',size=14)]
action(s,222,216,'New diagram',icon='doc');action(s,478,182,'Edit title',icon='doc');action(s,478,216,'Node details',icon='doc');action(s,666,182,'Show / hide notes',icon='doc');action(s,666,216,'Delete node',icon='trash');action(s,920,182,'Copy nodes',icon='doc');action(s,920,216,'Paste as children',icon='doc');action(s,1170,182,'Undo',icon='doc');action(s,1170,216,'Overdue log',icon='doc')
scene=fixture['Scene'];scale=min(1.2,(W-100)/scene['Width'],570/scene['Height']);dx=(W-scene['Width']*scale)/2;dy=285+(570-scene['Height']*scale)/2
s.append(f'<g transform="translate({dx} {dy}) scale({scale})">')
for mark in fixture['Marks']:
    d=mark['Data'];kind=mark['Kind']
    if kind=='PdfNodeShape':s.append(node_shape(d))
    elif kind=='PdfBox':s.append(rect(d['X'],d['Y'],d['Width'],d['Height'],d['Fill'],d['Stroke'],d['Radius']))
    elif kind=='PdfText':s.append(pdf_text(d))
    elif kind=='PdfLine':
        points=d['Points'];p='M'+str(points[0]['X'])+' '+str(points[0]['Y'])
        if d['Curve'] and len(points)==4:p+=' C'+' '.join(str(v) for q in points[1:] for v in [q['X'],q['Y']])
        else:p+=' '+' '.join('L'+str(q['X'])+' '+str(q['Y']) for q in points[1:])
        s.append(f'<path d="{p}" fill="none" stroke="{d["Colour"]}" stroke-width="{d["Thickness"]}"/>')
s += ['</g>',text(16,855,'9 nodes · Drag space to pan · Ctrl+wheel to zoom',size=15)]
save('SUMAPP-mind-map-design',s)

graph_fixture=json.loads((root / 'artifacts/export-checks/SUMAPP-graph-design.json').read_text())
s=frame('GRAPH')
s += [rect(12,162,190,28,T['Surface'],T['DarkTeal']),text(22,182,'Graph   ⌄',size=14),text(12,245,'APPLICATION',size=11)]
s += [rect(222,162,210,28,T['Surface'],T['DarkTeal']),text(232,182,'Engineering review  ⌄',size=14)]
action(s,222,216,'New diagram',icon='doc');action(s,478,182,'Edit title',icon='doc');action(s,478,216,'Node details',icon='doc');action(s,666,182,'Show / hide notes',icon='doc');action(s,666,216,'Delete node',icon='trash');action(s,920,182,'Copy nodes',icon='doc');action(s,920,216,'Paste as children',icon='doc');action(s,1170,182,'Undo',icon='doc');action(s,1170,216,'Overdue log',icon='doc')
scene=graph_fixture['Scene'];scale=min(1.2,(W-100)/scene['Width'],570/scene['Height']);dx=(W-scene['Width']*scale)/2;dy=285+(570-scene['Height']*scale)/2
s.append(f'<g transform="translate({dx} {dy}) scale({scale})">')
for mark in graph_fixture['Marks']:
    d=mark['Data'];kind=mark['Kind']
    if kind=='PdfNodeShape':s.append(node_shape(d))
    elif kind=='PdfBox':s.append(rect(d['X'],d['Y'],d['Width'],d['Height'],d['Fill'],d['Stroke'],d['Radius']))
    elif kind=='PdfText':s.append(pdf_text(d))
    elif kind=='PdfLine':
        points=d['Points'];p='M'+str(points[0]['X'])+' '+str(points[0]['Y'])
        if d['Curve'] and len(points)==4:p+=' C'+' '.join(str(v) for q in points[1:] for v in [q['X'],q['Y']])
        else:p+=' '+' '.join('L'+str(q['X'])+' '+str(q['Y']) for q in points[1:])
        s.append(f'<path d="{p}" fill="none" stroke="{d["Colour"]}" stroke-width="{d["Thickness"]}"/>')
s += ['</g>',text(16,855,'5 nodes · Multi-colour package applied · Drag space to pan · Ctrl+wheel to zoom',size=15)]
s += [rect(16,267,112,112,'#FFFFFF'),f'<image x="22" y="273" width="100" height="100" xlink:href="data:image/png;base64,{logo}"/>']
save('SUMAPP-graph-design',s)

def thumbnail(example, x, y, width, height):
    scene=example['Scene'];scale=min(width/scene['Width'],height/scene['Height']);dx=x+(width-scene['Width']*scale)/2;dy=y+(height-scene['Height']*scale)/2
    parts=[f'<g transform="translate({dx} {dy}) scale({scale})">']
    for mark in example['Marks']:
        d=mark['Data'];kind=mark['Kind']
        if kind=='PdfNodeShape':parts.append(node_shape(d))
        elif kind=='PdfBox':parts.append(rect(d['X'],d['Y'],d['Width'],d['Height'],d['Fill'],d['Stroke'],d['Radius']))
        elif kind=='PdfText':
            # At thumbnail scale, clear line motifs illustrate text without illegible micro-labels.
            if d['Size']>12:parts.append(f'<path d="M{d["X"]} {d["Y"]-5} h75" stroke="{d["Colour"]}" stroke-width="{1.4/scale}"/>')
        elif kind=='PdfLine':
            p=d['Points'];path='M'+str(p[0]['X'])+' '+str(p[0]['Y'])
            if d['Curve'] and len(p)==4:path+=' C'+' '.join(str(v) for q in p[1:] for v in [q['X'],q['Y']])
            else:path+=' '+' '.join('L'+str(q['X'])+' '+str(q['Y']) for q in p[1:])
            parts.append(f'<path d="{path}" fill="none" stroke="{d["Colour"]}" stroke-width="{1.2/scale}"/>')
    return parts+['</g>']

colour_rows=(len(gallery['Colours'])+3)//4
styles_heading=302+colour_rows*127+28
styles_start=styles_heading+16
layouts_heading=styles_start+((len(gallery['Styles'])+4)//5)*127+40
layouts_start=layouts_heading+16
H=layouts_start+((len(gallery['Layouts'])+4)//5)*178+110
s=frame('MIND MAP / WBS','Format')
s += [text(26,177,'Node designs',size=14,bold=True),text(708,177,'Colour combinations',size=14,bold=True)]
for i,index in enumerate([0,4,5,8]):
    item=gallery['Styles'][index];x=26+i*162
    s += thumbnail(item['Example'],x,184,148,40)+[text(x+8,240,item['Name'],size=12)]
for i,index in enumerate([28,29,31]):
    item=gallery['Colours'][index];x=708+i*176
    s += thumbnail(item['Example'],x,184,148,40)+[text(x+8,240,item['Name'],size=12)]
s += [text(1280,207,'▾ All options',T['DarkTeal'],16,True),text(24,286,str(len(gallery['Colours']))+' colour combinations',T['DarkTeal'],23,True),text(1050,284,'Each pack colours the nodes and connections',size=16)]
for i,item in enumerate(gallery['Colours']):
    x=24+(i%4)*390;y=302+(i//4)*127
    s += [rect(x,y,376,115,'#FFFFFF'),text(x+14,y+25,item['Name'],size=17,bold=True)]
    s += thumbnail(item['Example'],x+14,y+34,347,72)
s.append(text(24,styles_heading,str(len(gallery['Styles']))+' node designs',T['DarkTeal'],23,True))
for i,item in enumerate(gallery['Styles']):
    x=24+(i%5)*312;y=styles_start+(i//5)*127
    s += [rect(x,y,298,115,'#FFFFFF'),text(x+12,y+25,item['Name'],size=17,bold=True)]
    s += thumbnail(item['Example'],x+12,y+34,274,72)
s.append(text(24,layouts_heading,str(len(gallery['Layouts']))+' diagram layouts · View tab',T['DarkTeal'],23,True))
for i,item in enumerate(gallery['Layouts']):
    x=24+(i%5)*312;y=layouts_start+(i//5)*178
    s += [rect(x,y,298,170,'#FFFFFF'),text(x+12,y+25,item['Name'],size=15,bold=True)]
    s += thumbnail(item['Example'],x+12,y+36,274,120)
save('SUMAPP-diagram-gallery-design',s)
print('Design previews rendered from Core geometry and tokens; not Windows screenshots:',out)

# Explicit node-shape and register colour galleries use the same exported geometry/tokens.
H=1100
s=frame('GRAPH','Format')
s += [text(24,177,'Selected node shape  ▾     Diagram shape  ▾',size=14),text(700,177,'Colour presets  ▾     Row design  ▾',size=14),text(24,287,'11 node shapes · selected nodes or whole diagram',T['DarkTeal'],24,True)]
for i,item in enumerate(shapes['Shapes'][1:]):
    x=24+(i%4)*390;y=310+(i//4)*170
    s += [rect(x,y,376,158,'#FFFFFF'),text(x+14,y+26,item['Name'],size=17,bold=True)]+thumbnail(item['Example'],x+14,y+34,345,112)
s += [text(24,860,'8 register colour presets · 4 row designs',T['DarkTeal'],24,True)]
for i,c in enumerate(shapes['Registers']):
    x=24+(i%4)*390;y=885+(i//4)*72
    s += [rect(x,y,376,62,c['Background']),rect(x,y,376,22,c['Header']),text(x+10,y+16,c['Name'],c['HeaderText'],13,True),rect(x,y+22,376,19,c['Row']),text(x+10,y+36,'Engineering review',c['Text'],12),rect(x,y+41,376,19,c['Alternate']),text(x+10,y+55,'Fabrication task',c['Text'],12)]
save('SUMAPP-shapes-register-design',s)
